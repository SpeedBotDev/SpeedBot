﻿namespace SpeedrunComSharp
{
    public enum EmulatorsFilter
    {
        NotSet,
        OnlyEmulators,
        NoEmulators
    }
}
