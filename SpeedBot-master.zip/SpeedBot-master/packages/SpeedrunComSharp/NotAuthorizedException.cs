﻿using System;

namespace SpeedrunComSharp
{
    public class NotAuthorizedException : Exception
    {
    }
}
