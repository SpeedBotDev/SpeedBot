﻿namespace SpeedrunComSharp
{
    public enum VariableScopeType
    {
        Global, FullGame, AllLevels, SingleLevel
    }
}
