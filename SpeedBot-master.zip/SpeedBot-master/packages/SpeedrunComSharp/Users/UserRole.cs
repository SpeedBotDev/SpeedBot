﻿namespace SpeedrunComSharp
{
    public enum UserRole
    {
        Banned, User, Trusted, Moderator, Admin, Programmer
    }
}
