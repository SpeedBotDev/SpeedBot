﻿namespace SpeedrunComSharp
{
    public enum PlayersType
    {
        Exactly, UpTo
    }
}
