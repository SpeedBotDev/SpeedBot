﻿namespace SpeedrunComSharp
{
    public enum ModeratorType
    {
        Moderator,
        SuperModerator
    }
}
