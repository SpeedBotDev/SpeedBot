﻿namespace SpeedrunComSharp
{
    public interface IElementWithID
    {
        string ID { get; }
    }
}
