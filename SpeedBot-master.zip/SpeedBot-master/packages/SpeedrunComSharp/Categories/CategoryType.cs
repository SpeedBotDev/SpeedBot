﻿namespace SpeedrunComSharp
{
    public enum CategoryType
    {
        PerGame, PerLevel
    }
}
