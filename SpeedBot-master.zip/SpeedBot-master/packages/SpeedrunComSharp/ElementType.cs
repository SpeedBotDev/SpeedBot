﻿namespace SpeedrunComSharp
{
    public enum ElementType
    {
        Category,
        Game,
        Guest,
        Level,
        Notification,
        Platform,
        Region,
        Run,
        Series,
        User,
        Variable
    }
}
