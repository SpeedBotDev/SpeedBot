﻿namespace SpeedrunComSharp
{
    public enum RunStatusType
    {
        New, Verified, Rejected
    }
}
